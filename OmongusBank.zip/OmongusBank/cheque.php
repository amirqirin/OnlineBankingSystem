<?php
// Assuming you have the database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "obank";

// Create a new MySQLi connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Process the form data here
    $accountNumber = $_POST["accountNumber"];
    $chequeBookType = $_POST["chequeBookType"];

    // Prepare and execute the INSERT statement
    $stmt = $conn->prepare("INSERT INTO customercheque (accNum, type) VALUES (?, ?)");
    $stmt->bind_param("is", $accountNumber, $chequeBookType);
    $stmt->execute();

    // Close the statement
    $stmt->close();

    // Assuming the form processing is successful
    // Display the thanks message and the "Go Back" button
    echo '<!DOCTYPE html>
    <html>
    <head>
      <title>Cheque Book Request</title>
      <link rel="stylesheet" type="text/css" href="cheque.css">
    </head>
    <body>
      <header>
        <h1>Cheque Book Request</h1>
      </header>

      <div class="container">
        <h2>Thank you for submitting your cheque book request!</h2>
        <button class="goback-button" onclick="window.location.href=\'mainpage.html\'">Go Back to Main Page</button>
      </div>

      <footer>
        <p>&copy; 2023 Omongus Bank. All rights reserved.</p>
      </footer>

    </body>
    </html>';

    // Close the database connection
    $conn->close();
} else {
    // Display the form as usual
    echo '<!DOCTYPE html>
    <html>
    <head>
      <title>Cheque Book Request</title>
      <link rel="stylesheet" type="text/css" href="cheque.css">
      <script>
        function showAlert() {
          alert("Cheque book request submitted successfully!");
          window.location.href = "cheque.html";
          return false; // Prevent form submission
        }
      </script>
    </head>
    <body>
      <header>
        <h1>Cheque Book Request</h1>
      </header>

      <div class="container">
        <form action="cheque.php" method="post" onsubmit="return showAlert()">
          <div class="form-group">
            <label for="accountNumber">Account Number:</label>
            <input type="text" id="accountNumber" name="accountNumber" required>
          </div>
          <div class="form-group">
            <label for="chequeBookType">Cheque Book Type:</label>
            <select id="chequeBookType" name="chequeBookType" required>
              <option value="personal">Personal</option>
              <option value="business">Business</option>
            </select>
          </div>
          <button type="submit" name="submit">Submit Request</button>
          <button type="button" onclick="window.location.href=\'mainpage.html\'">Cancel</button>
          <button type="button" onclick="window.history.back()">Back</button>
        </form>
      </div>

      <footer>
        <p>&copy; 2023 Omongus Bank. All rights reserved.</p>
      </footer>

    </body>
    </html>';

    // Close the database connection
    $conn->close();
}
?>
