<!DOCTYPE html>
<html>
<head>
  <title>Bank Administrator</title>
  <style>
    body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
  }
  
  #header {
    background-color: #0097B2;
    padding: 20px;
  }
  
  #header .container {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  
  #header h1 {
    margin: 0;
  }
  
  #header p {
    margin: 0;
  }
  
  #content {
    padding: 20px;
  }
  
  .options {
    display: flex;
    justify-content: space-between;
    margin-top: 0px;
	align-items: center;
  }
  
  .options a {
    text-decoration: none;
    padding: 10px 20px;
    border: 1px solid #ccc;
    background-color: #0097B2;
    color: #333;
    border-radius: 5px;
	flex:1;
	text-align: center;
  }
  
  .options a:hover {
    background-color: #e0e0e0;
  }
  
  .options a.active {
    background-color: orange;
    color: #fff;
  }
  
   .form-box {
      border: 1px solid #ccc;
      padding: 20px;
      border-radius: 5px;
      background-color: #f5f5f5;
      margin-top: 20px;
    }
    
    form {
      margin-top: 20px;
    }
    
    form label {
      display: block;
      margin-bottom: 10px;
    }
    
    form input[type="text"],
    form input[type="password"],
    form input[type="email"],
    form textarea {
      width: 100%;
      padding: 8px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }
    
    .form-row {
      margin-bottom: 10px;
	  display: flex;
	  align-items:center;
    }
    
    .form-row label {
      display: block;
    }
    
    .form-row input[type="radio"] {
      margin-right: 5px;
    }
    
    .form-row .radio-label {
      display: flex;
      align-items: center;
    }
    
    .form-row .radio-label input[type="radio"] {
      margin-right: 5px;
    }
    
    .form-row textarea {
      resize: vertical;
    }
    
    form input[type="submit"] {
      padding: 10px 20px;
      background-color: #4CAF50;
      color: #fff;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
    
    form input[type="submit"]:hover {
      background-color: #45a049;
    }
	table {
    border-collapse: collapse;
    width: 100%;
    margin-bottom: 20px;
	align-items: center;
	
  }
  
  th, td {
    border: 1px solid #ccc;
    padding: 8px;
    text-align: center;
  }
  
  th {
    background-color: #f5f5f5;
  }
  </style>
</head>
<body>
  <div id="header">
    <div class="container">
      <h1>O'Mongus Bank</h1>
      <p>Welcome Administrator!</p>
      <p id="datetime"></p>
    </div>
    <script>
      // Update date and time
      setInterval(function() {
        var now = new Date();
        var datetime = now.toLocaleString();
        document.getElementById("datetime").innerHTML = datetime;
      }, 1000);
    </script>
  </div>
  
  <div id="content">
    <div class="options">
      <a href="request.php">Request</a>
      <a href="accountp.php">Account</a>
      <a href="transaction.html" >Transaction</a>
      <a href="Announcementp.php" >Announcement</a>
      <a href="settings.html" class="active">Settings</a>
      <a href="log out .html">Log Out</a>
    </div>
<?php
// Establish a connection to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "obank";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve the form data
    $name = $_POST['name'];
    $about = $_POST['about'];
    $viewOrModify = $_POST['viewOrModify'];

    // Check if logo and cover are uploaded
    if (isset($_FILES['logo']['tmp_name']) && isset($_FILES['cover']['tmp_name'])) {
        $logo = $_FILES['logo']['tmp_name'];
        $cover = $_FILES['cover']['tmp_name'];

        // Prepare the SQL statement
        $stmt = $conn->prepare("INSERT INTO settingadmin (nameBank, aboutBank, viewBank, imageBank, coverImageBank) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $name, $about, $viewOrModify, $logoData, $coverData);

        // Read the image files and convert them to binary data
        $logoData = file_get_contents($logo);
        $coverData = file_get_contents($cover);
    } else {
        // Prepare the SQL statement without logo and cover
        $stmt = $conn->prepare("INSERT INTO settingadmin (nameBank, aboutBank, viewBank) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $about, $viewOrModify);
    }

    // Execute the statement
    if ($stmt->execute()) {
        // Data inserted successfully
        echo '<!DOCTYPE html>
        <html>
        <head>
          <title>Setting Form</title>
          <link rel="stylesheet" type="text/css" href="setting.css">
        </head>
        <body>
          <header>
            <h1>Settings</h1>
          </header>
        
          <div class="container">
            <h2>Setting request submitted succesfully! &#128522;</h2>
            <button class="goback-button" onclick="window.location.href=\'settings.html\'">Back</button>
          </div>
        
        </body>
        </html>';
    } else {
        // Error inserting data
        echo '<script>alert("Setting unsuccessful: ' . $stmt->error . '");</script>';
    }

    // Close the statement
    $stmt->close();
}

// Close the database connection
$conn->close();
?>
</body>
</html>
