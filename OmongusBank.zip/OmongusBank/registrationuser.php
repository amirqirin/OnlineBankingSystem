<?php
if (isset($_POST['submit'])) {
  // Get the submitted form data
  $debitCardINo = $_POST['debitCardINo'];
  $pin = $_POST['pin'];
  $cardType = $_POST['cardType'];

  // Database connection settings
  $host = "localhost"; // Change if necessary
  $dbUsername = "root"; // Change if necessary
  $dbPassword = ""; // Change if necessary
  $dbName = "banking_system"; // Change to your database name

  // Create a new PDO instance
  $conn = new PDO("mysql:host=$host;dbname=$dbName", $dbUsername, $dbPassword);
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  // Perform additional validation as needed

  // Insert the form data into the database
  $stmt = $conn->prepare("INSERT INTO users (debitCardINo, pin, cardType) VALUES (?, ?, ?)");
  $stmt->execute([$debitCardINo, $pin, $cardType]);

  // Redirect to the login page after successful registration
  header("Location: login.html");
  exit();
}
?>
