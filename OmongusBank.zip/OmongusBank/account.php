<!DOCTYPE html>
<html>
<head>
  <title>Bank Administrator</title>
  <style>
    body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
  }
  
  #header {
    background-color: #0097B2;
    padding: 20px;
  }
  
  #header .container {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  
  #header h1 {
    margin: 0;
  }
  
  #header p {
    margin: 0;
  }
  
  #content {
    padding: 20px;
  }
  
  .options {
    display: flex;
    justify-content: space-between;
    margin-top: 0px;
	align-items: center;
  }
  
  .options a {
    text-decoration: none;
    padding: 10px 20px;
    border: 1px solid #ccc;
    background-color: #0097B2;
    color: #333;
    border-radius: 5px;
	flex:1;
	text-align: center;
  }
  
  .options a:hover {
    background-color: #e0e0e0;
  }
  
  .options a.active {
    background-color: orange;
    color: #fff;
  }
  
   .form-box {
      border: 1px solid #ccc;
      padding: 20px;
      border-radius: 5px;
      background-color: #f5f5f5;
      margin-top: 20px;
    }
    
    form {
      margin-top: 20px;
    }
    
    form label {
      display: block;
      margin-bottom: 10px;
    }
    
    form input[type="text"],
    form input[type="password"],
    form input[type="email"],
    form textarea {
      width: 100%;
      padding: 8px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }
    
    .form-row {
      margin-bottom: 10px;
	  display: flex;
	  align-items:center;
    }
    
    .form-row label {
      display: block;
    }
    
    .form-row input[type="radio"] {
      margin-right: 5px;
    }
    
    .form-row .radio-label {
      display: flex;
      align-items: center;
    }
    
    .form-row .radio-label input[type="radio"] {
      margin-right: 5px;
    }
    
    .form-row textarea {
      resize: vertical;
    }
    
    form input[type="submit"] {
      padding: 10px 20px;
      background-color: #4CAF50;
      color: #fff;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
    
    form input[type="submit"]:hover {
      background-color: #45a049;
    }
	table {
    border-collapse: collapse;
    width: 100%;
    margin-bottom: 20px;
	align-items: center;
	
  }
  
  th, td {
    border: 1px solid #ccc;
    padding: 8px;
    text-align: center;
  }
  
  th {
    background-color: #f5f5f5;
  }
  </style>
</head>
<body>
  <div id="header">
    <div class="container">
      <h1>O'Mongus Bank</h1>
      <p>Welcome Administrator!</p>
      <p id="datetime"></p>
    </div>
    <script>
      // Update date and time
      setInterval(function() {
        var now = new Date();
        var datetime = now.toLocaleString();
        document.getElementById("datetime").innerHTML = datetime;
      }, 1000);
    </script>
  </div>
  
  <div id="content">
    <div class="options">
      <a href="request.php">Request</a>
      <a href="accountp.php" class="active">Account</a>
      <a href="transaction.html" >Transaction</a>
      <a href="Announcementp.php" >Announcement</a>
      <a href="settings.html" >Settings</a>
      <a href="log out .html">Log Out</a>
    </div>

<?php
// Establish a connection to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "obank";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve the form data
    $accountNumber = $_POST['accountNumber'];
    $pin = $_POST['pin'];
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepare the SQL statement
    $stmt = $conn->prepare("INSERT INTO newaccountadmin (newAccNumAdmin, pinNewAccAdmin, firstnameAdmin, lastNameAdmin, emailAdmin, passwordAdmin) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("iissss", $accountNumber, $pin, $firstName, $lastName, $email, $password);

    // Execute the statement
    if ($stmt->execute()) {
        // Data inserted successfully
        echo '<div class="thank-you-message">
                <h2>Thank you for creating the account! &#128522;</h2>
                <button class="home-button" onclick="window.location.href=\'accountp.php\'">Back</button>
              </div>';
    } else {
        // Error inserting data
        echo '<script>alert("Account not received, Click undo to continue with other option ' . $stmt->error . '");</script>';
    }

    // Close the statement
    $stmt->close();
}

// Close the database connection
$conn->close();
?>
</body>
</html>
