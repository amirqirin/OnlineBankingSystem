<!DOCTYPE html>
<html>
<head>
  <title>Bank Administrator</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
    }
    
    #header {
      background-color: #0097B2;
      padding: 20px;
    }
    
    #header .container {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    #header h1 {
      margin: 0;
    }
    
    #header p {
      margin: 0;
    }
    
    #content {
      padding: 20px;
    }
    
    .options {
      display: flex;
      justify-content: space-between;
      margin-top: 0px;
    }
    
    .options a {
    text-decoration: none;
    padding: 10px 20px;
    border: 1px solid #ccc;
    background-color: #0097B2;
    color: #333;
    border-radius: 5px;
	flex:1;
	text-align: center;
	}
    
    .options a:hover {
      background-color: #e0e0e0;
    }
	.options a.active {
    background-color: orange;
    color: #fff;
	}
    
    .form-box {
      border: 1px solid #ccc;
      padding: 20px;
      border-radius: 5px;
      background-color: #f5f5f5;
      margin-top: 20px;
    }
    
    form {
      margin-top: 20px;
    }
    
    form label {
      display: block;
      margin-bottom: 10px;
    }
    
    form input[type="text"],
    form input[type="password"],
    form input[type="email"] {
      width: 100%;
      padding: 8px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }
    
    .form-row {
      display: flex;
      justify-content: space-between;
      margin-bottom: 10px;
    }
    
    .form-row input {
      flex: 1;
      margin-right: 10px;
    }
    
    form input[type="submit"] {
      padding: 10px 20px;
      background-color: #4CAF50;
      color: #fff;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
    
    form input[type="submit"]:hover {
      background-color: #45a049;
    }
	table {
    border-collapse: collapse;
    width: 100%;
    margin-bottom: 20px;
  }
  
  th, td {
    border: 1px solid #ccc;
    padding: 8px;
    text-align: left;
  }
  
  th {
    background-color: #f5f5f5;
  }

  </style>
</head>
<body>
  <div id="header">
    <div class="container">
      <h1>O'Mongus Bank</h1>
      <p>Welcome Administrator</p>
      <p id="datetime"></p>
    </div>
    <script>
      // Update date and time
      setInterval(function() {
        var now = new Date();
        var datetime = now.toLocaleString();
        document.getElementById("datetime").innerHTML = datetime;
      }, 1000);
    </script>
  </div>
  
  <div id="content">
    <div class="options">
      <a href="request.php">Request</a>
      <a href="accountp.php" class="active">Account</a>
      <a href="transaction.html">Transaction</a>
      <a href="Announcementp.php">Announcement</a>
      <a href="settings.html">Settings</a>
      <a href="log out .html">Log Out</a>
    </div>
    
    <div class="form-box">
      <form action="account.php" method="post" onsubmit="return validateForm()">
        <h2>Create New Account</h2>
        <div class="form-row">
          <label for="accountNumber">Account Number:</label>
          <input type="text" id="accountNumber" name="accountNumber">
          <label for="pin">PIN:</label>
          <input type="password" id="pin" name="pin">
        </div>
        <div class="form-row">
          <label for="firstName">First Name:</label>
          <input type="text" id="firstName" name="firstName">
          <label for="lastName">Last Name:</label>
          <input type="text" id="lastName" name="lastName">
        </div>
        <div class="form-row">
          <label for="email">Email:</label>
          <input type="email" id="email" name="email">
          <label for="password">Password:</label>
          <input type="password" id="password" name="password">
        </div>
        <input type="submit" value="Create">
      </form>
    </div>
	<script>
function validateForm() {
  var accountNumber = document.getElementById("accountNumber").value;
  var pin = document.getElementById("pin").value;
  var firstName = document.getElementById("firstName").value;
  var lastName = document.getElementById("lastName").value;
  var email = document.getElementById("email").value;
  var password = document.getElementById("password").value;

  if (
    accountNumber === "" ||
    pin === "" ||
    firstName === "" ||
    lastName === "" ||
    email === "" ||
    password === ""
  ) {
    alert("Please fill in all fields");
    return false; // Prevent form submission
  }
}
</script>
	<h2>List Of Account Created</h2>
<table>
  <tr>
    <th>Account Number</th>
    <th>Email</th>
    <th>Name</th>
  </tr>
 <?php
// Establish a connection to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "obank";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
  // Retrieve data from the database
  $query = "SELECT * FROM newaccountadmin";
  $result = $conn->query($query);

  if ($result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {
          echo '<tr>';
          echo '<td>' . $row['newAccNumAdmin'] . '</td>';
          echo '<td>' . $row['emailAdmin'] . '</td>';
          echo '<td>' . $row['firstNameAdmin'] . ' ' . $row['lastNameAdmin'] . '</td>';
          echo '</tr>';
      }
  } else {
      echo '<tr><td colspan="3">No accounts found.</td></tr>';
  }
  // Close the database connection
$conn->close();
?>
</table>

  </div>
</body>
</html>
