<!DOCTYPE html>
<html>
<head>
  <title>Bank Administrator</title>
  <style>
    body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
  }
  
  #header {
    background-color: #0097B2;
    padding: 20px;
  }
  
  #header .container {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  
  #header h1 {
    margin: 0;
  }
  
  #header p {
    margin: 0;
  }
  
  #content {
    padding: 20px;
  }
  
  .options {
    display: flex;
    justify-content: space-between;
    margin-top: 0px;
	align-items: center;
  }
  
  .options a {
    text-decoration: none;
    padding: 10px 20px;
    border: 1px solid #ccc;
    background-color: #0097B2;
    color: #333;
    border-radius: 5px;
	flex:1;
	text-align: center;
  }
  
  .options a:hover {
    background-color: #e0e0e0;
  }
  
  .options a.active {
    background-color: orange;
    color: #fff;
  }
  
   .form-box {
      border: 1px solid #ccc;
      padding: 20px;
      border-radius: 5px;
      background-color: #f5f5f5;
      margin-top: 20px;
    }
    
    form {
      margin-top: 20px;
    }
    
    form label {
      display: block;
      margin-bottom: 10px;
    }
    
    form input[type="text"],
    form input[type="password"],
    form input[type="email"],
    form textarea {
      width: 100%;
      padding: 8px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }
    
    .form-row {
      margin-bottom: 10px;
	  display: flex;
	  align-items:center;
    }
    
    .form-row label {
      display: block;
    }
    
    .form-row input[type="radio"] {
      margin-right: 5px;
    }
    
    .form-row .radio-label {
      display: flex;
      align-items: center;
    }
    
    .form-row .radio-label input[type="radio"] {
      margin-right: 5px;
    }
    
    .form-row textarea {
      resize: vertical;
    }
    
    form input[type="submit"] {
      padding: 10px 20px;
      background-color: #4CAF50;
      color: #fff;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
    
    form input[type="submit"]:hover {
      background-color: #45a049;
    }
	table {
    border-collapse: collapse;
    width: 100%;
    margin-bottom: 20px;
	align-items: center;
	
  }
  
  th, td {
    border: 1px solid #ccc;
    padding: 8px;
    text-align: center;
  }
  
  th {
    background-color: #f5f5f5;
  }
  </style>
</head>
<body>
  <div id="header">
    <div class="container">
      <h1>O'Mongus Bank</h1>
      <p>Welcome Administrator!</p>
      <p id="datetime"></p>
    </div>
    <script>
      // Update date and time
      setInterval(function() {
        var now = new Date();
        var datetime = now.toLocaleString();
        document.getElementById("datetime").innerHTML = datetime;
      }, 1000);
    </script>
  </div>
  
  <div id="content">
    <div class="options">
      <a href="request.php">Request</a>
      <a href="accountp.php">Account</a>
      <a href="transaction.html" >Transaction</a>
      <a href="Announcementp.php" class="active">Announcement</a>
      <a href="settings.html">Settings</a>
      <a href="log out .html">Log Out</a>
    </div>

    <div class="form-box">
      <form action="Announcement.php" method="post" onsubmit="return validateForm()">
          <h2>Create Announcement</h2>
          <div class="form-row">
              <label for="comment">Comment:</label>
              <textarea id="comment" name="comment" rows="5" required></textarea>
          </div>
          <div class="form-row">
              <label for="publish">Publishment Details:</label>
              <select id="publish" name="publish" required>
                  <option value="Publish to Online User Application">Publish to Online User Application</option>
                  <option value="Publish to All Advertisement Platform">Publish to All Advertisement Platform</option>
              </select>
          </div>
          <div class="form-row">
              <label for="title">Title:</label>
              <input type="text" id="title" name="title" required>
          </div>
          <div class="form-row">
              <label for="passcode">Authentication Passcode:</label>
              <input type="password" id="passcode" name="passcode" required>
          </div>
          <div class="form-row">
              <input type="submit" value="Submit">
          </div>
      </form>
    </div>

    <h2>Announcement</h2>
    <table id="announcementTable">
      <tr>
        <th>Publish</th>
        <th>Title</th>
        <th>Comment</th>
        <th>Actions</th>
      </tr>
      <?php
      // Establish a connection to the database
      $servername = "localhost";
      $username = "root";
      $password = "";
      $dbname = "obank";

      $conn = new mysqli($servername, $username, $password, $dbname);

      // Check the connection
      if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
      }

      // Handle delete request
      if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
          $id = $_GET['id'];
          $deleteQuery = "DELETE FROM announcementadmin WHERE id = ?";
          $stmt = $conn->prepare($deleteQuery);
          $stmt->bind_param("i", $id);
          if ($stmt->execute()) {
              echo "Announcement deleted successfully.";
          } else {
              echo "Error deleting announcement: " . $stmt->error;
          }
      }

      // Retrieve data from the database
      $query = "SELECT * FROM announcementadmin";
      $result = $conn->query($query);

      // Display the data in the table
      if ($result && $result->num_rows > 0) {
          while ($row = $result->fetch_assoc()) {
              echo '<tr>';
              echo '<td>' . $row['publish'] . '</td>';
              echo '<td>' . $row['title'] . '</td>';
              echo '<td>' . $row['comment'] . '</td>';
              echo '<td>';
              echo '<a href="Announcementp.php?action=delete&id=' . $row['id'] . '"><button style="background-color: blue; color: white;">Delete</button></a>';
              echo '</td>';
              echo '</tr>';
          }
      } else {
          echo '<tr><td colspan="4">No announcements found.</td></tr>';
      }

      // Close the database connection
      $conn->close();
      ?>
    </table>
  </div>

  <script>
    function validateForm() {
        var comment = document.getElementById("comment").value;
        var publish = document.getElementById("publish").value;
        var title = document.getElementById("title").value;
        var passcode = document.getElementById("passcode").value;

        if (comment === "" || publish === "" || title === "" || passcode === "") {
            alert("Please fill in all fields");
            return false; // Prevent form submission
        }
    }
  </script>
</body>
</html>
