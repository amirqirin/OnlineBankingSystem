<?php
// Establish a connection to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "obank";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve the form data
    $fromAccount = $_POST['fromAccount'];
    $toAccount = $_POST['toAccount'];
    $transferAmount = $_POST['transferAmount'];
    $effectiveDate = $_POST['effectiveDate'];
    $transferDescription = $_POST['transferDescription'];

    // Prepare the SQL statement
    $stmt = $conn->prepare("INSERT INTO fundtransfercust (fromAcc, toAcc, transferAmount, transferDate, transferDesc) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssiss", $fromAccount, $toAccount, $transferAmount, $effectiveDate, $transferDescription);

    // Execute the statement
    if ($stmt->execute()) {
        // Data inserted successfully
        echo '<!DOCTYPE html>
        <html>
        <head>
          <title>Fund Transfer</title>
          <link rel="stylesheet" type="text/css" href="fundtransfer.css">
        </head>
        <body>
          <header>
            <h1>Fund Transfer</h1>
          </header>
        
          <div class="container">
            <h2>Transfer successful! Thank you for using our services. &#128522;</h2>
            <button class="goback-button" onclick="window.location.href=\'mainpage.html\'">Go Back to Main Page</button>
          </div>
        
          <footer>
            <p>&copy; 2023 OMongus Bank. All rights reserved.</p>
          </footer>
        
        </body>
        </html>';
    } else {
        // Error inserting data
        echo '<script>alert("Transfer unsuccessful: ' . $stmt->error . '");</script>';
    }

    // Close the statement
    $stmt->close();
}

// Close the database connection
$conn->close();
?>
