<?php
// Establish a connection to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "obank";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve the form data
    $userId = $_POST['userId'];
    $newPassword = $_POST['newPassword'];
    $confirmPassword = $_POST['confirmPassword'];

    // Check if the new password and confirm password match
    if ($newPassword === $confirmPassword) {
        // Check if the username exists in the customerlogin table
        $stmt = $conn->prepare("SELECT usernameCust FROM customerlogin WHERE usernameCust = ?");
        $stmt->bind_param("s", $userId);
        $stmt->execute();
        $stmt->store_result();

        // If the username exists, update the password
        if ($stmt->num_rows > 0) {
            $stmt->close();
            // Update the password in the customerlogin table
            $stmt = $conn->prepare("UPDATE customerlogin SET passwordCust = ? WHERE usernameCust = ?");
            $stmt->bind_param("ss", $newPassword, $userId);
            $stmt->execute();

            // Display an alert message for successful password change
            echo '<script>alert("Password changed successfully.");</script>';

            // Redirect to the login page after successful password reset
            echo '<script>window.location.href = "loginuser.html";</script>';
            exit();
        } else {
            // Display an alert message for invalid username
            echo '<script>alert("Username does not exist.");</script>';

            // Redirect to the forgot password page
            echo '<script>window.location.href = "forgotpass.html";</script>';
            exit();
        }
    } else {
        // Display an alert message for password mismatch
        echo '<script>alert("New password and confirm password do not match.");</script>';

        // Redirect to the forgot password page
        echo '<script>window.location.href = "forgotpass.html";</script>';
        exit();
    }
}

// Close the database connection
$conn->close();
?>
