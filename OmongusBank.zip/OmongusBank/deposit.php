<?php
// Establish a connection to the phpMyAdmin database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "obank";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve the form data
    $accountNumber = $_POST['accountNumber'];
    $amount = $_POST['amount'];

    // Prepare the SQL statement
    $stmt = $conn->prepare("INSERT INTO customerdeposit (accountNumber, amountDeposit) VALUES (?, ?)");
    $stmt->bind_param("ii", $accountNumber, $amount);

    // Execute the statement
    if ($stmt->execute()) {
        // Data inserted successfully
        echo '<!DOCTYPE html>
        <html>
        <head>
          <title>Deposit</title>
          <link rel="stylesheet" type="text/css" href="deposit.css">
        </head>
        <body>
          <header>
            <h1>Deposit</h1>
          </header>
        
          <div class="container">
            <h2>Deposit successful! Thank you for using our services. &#128522;</h2>
            <button class="goback-button" onclick="window.location.href=\'mainpage.html\'">Go Back to Main Page</button>
          </div>
        
          <footer>
            <p>&copy; 2023 OMongus Bank. All rights reserved.</p>
          </footer>
        
        </body>
        </html>';
    } else {
        // Error inserting data
        echo '<script>alert("Deposit unsuccessful: ' . $stmt->error . '");</script>';
    }

    // Close the statement
    $stmt->close();
}

// Close the database connection
$conn->close();
?>
