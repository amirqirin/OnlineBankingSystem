<?php
// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Get the submitted username and password
  $username = $_POST['username'];
  $password = $_POST['password'];

  // Database connection settings
  $host = "localhost"; // Change if necessary
  $dbUsername = "root"; // Change if necessary
  $dbPassword = ""; // Change if necessary
  $dbName = "obank"; // Change if necessary

  // Create a new PDO instance
  $conn = new PDO("mysql:host=$host;dbname=$dbName", $dbUsername, $dbPassword);
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  // Prepare and execute the query
  $stmt = $conn->prepare("SELECT * FROM adminlogin WHERE usernameAdmin = :username");
  $stmt->bindParam(':username', $username);
  $stmt->execute();

  // Check if a user with the given username exists
  $user = $stmt->fetch(PDO::FETCH_ASSOC);
  if ($user) {
    // Verify the password
    if ($password === $user['passwordAdmin']) {
      // Redirect to the dashboard or homepage after successful login
      header("Location: request.php");
      exit();
    } else {
      // Display an error message if the password is incorrect
      echo "Invalid username or password";
    }
  } else {
    // Display an error message if the username is incorrect
    echo "Invalid username or password";
  }
}
?>
