<!DOCTYPE html>
<html>
<head>
  <title>Bank Administrator</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
    }

    #header {
      background-color: #0097B2;
      padding: 20px;
    }

    #header .container {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    #header h1 {
      margin: 0;
    }

    #header p {
      margin: 0;
    }

    #content {
      padding: 20px;
    }

    .options {
      display: flex;
      justify-content: space-between;
      margin-top: 0px;
    }

    .options a {
      text-decoration: none;
      padding: 10px 20px;
      border: 1px solid #ccc;
      background-color: #0097B2;
      color: #333;
      border-radius: 5px;
      flex:1;
      text-align: center;
    }

    .options a:hover {
      background-color: #e0e0e0;
    }

    .options a.active {
      background-color: orange;
      color: #fff;
    }

    table {
      border-collapse: collapse;
      width: 100%;
      margin-bottom: 20px;
    }

    th, td {
      border: 1px solid #ccc;
      padding: 8px;
      text-align: left;
    }

    th {
      background-color: #f5f5f5;
    }
  </style>
</head>
<body>
  <div id="header">
    <div class="container">
      <h1>O'Mongus Bank</h1>
      <p>Welcome Administrator!</p>
      <p id="datetime"></p>
    </div>
    <script>
      // Update date and time
      setInterval(function() {
        var now = new Date();
        var datetime = now.toLocaleString();
        document.getElementById("datetime").innerHTML = datetime;
      }, 1000);
    </script>
  </div>

  <div id="content">
    <div class="options">
      <a href="request.php" class="active">Request</a>
      <a href="accountp.php">Account</a>
      <a href="transaction.html">Transaction</a>
      <a href="Announcementp.php">Announcement</a>
      <a href="settings.html">Settings</a>
      <a href="log out .html">Log Out</a>
    </div>

    <h2>Payment</h2>

    <table>
      <?php
      // Establish a connection to the database
      $servername = "localhost";
      $username = "root";
      $password = "";
      $dbname = "obank";

      $conn = new mysqli($servername, $username, $password, $dbname);

      // Check the connection
      if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
      }

      // Retrieve data from the database for Payment
      $paymentQuery = "SELECT * FROM paymentcust";
      $paymentResult = $conn->query($paymentQuery);

      // Display the Payment data in the table
      if ($paymentResult && $paymentResult->num_rows > 0) {
          echo '<table>
                  <tr>
                      <th>Account Number</th>
                      <th>Amount</th>
                      <th>From Bank</th>
                      <th>Biller</th>
                  </tr>';
          while ($row = $paymentResult->fetch_assoc()) {
              echo '<tr>';
              echo '<td>' . $row['holderNum'] . '</td>';
              echo '<td>' . $row['amount'] . '</td>';
              echo '<td>' . $row['fromAccount'] . '</td>';
              echo '<td>' . $row['biller'] . '</td>';
              echo '</tr>';
          }
          echo '</table>';
      } else {
          echo '<p>No payment records found.</p>';
      }

      // Close the Payment result
      $paymentResult->close();

      ?>

    </table>

    <h2>Investment</h2>

    <table>
      <?php
      // Retrieve data from the database for Investment
      $investmentQuery = "SELECT * FROM customerinvestment";
      $investmentResult = $conn->query($investmentQuery);

      // Display the Investment data in the table
      if ($investmentResult && $investmentResult->num_rows > 0) {
          echo '<table>
                  <tr>
                      <th>Account Number</th>
                      <th>Amount</th>
                      <th>Term (month)</th>
                  </tr>';
          while ($row = $investmentResult->fetch_assoc()) {
              echo '<tr>';
              echo '<td>' . $row['accNumInvest'] . '</td>';
              echo '<td>' . $row['amountInvest'] . '</td>';
              echo '<td>' . $row['term'] . '</td>';
              echo '</tr>';
          }
          echo '</table>';
      } else {
          echo '<p>No investment records found.</p>';
      }

      // Close the Investment result
      $investmentResult->close();

      ?>

    </table>

    <h2>Chequebook Request</h2>

    <table>
      <?php
      // Handle delete request
      if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
          $id = $_GET['id'];
          $deleteQuery = "DELETE FROM customercheque WHERE id = ?";
          $stmt = $conn->prepare($deleteQuery);
          $stmt->bind_param("i", $id);
          if ($stmt->execute()) {
              echo "Chequebook request deleted successfully.";
          } else {
              echo "Error deleting chequebook request: " . $stmt->error;
          }
      }

      // Retrieve data from the database for Chequebook Request
      $chequebookQuery = "SELECT * FROM customercheque";
      $chequebookResult = $conn->query($chequebookQuery);

      // Display the Chequebook Request data in the table
      if ($chequebookResult && $chequebookResult->num_rows > 0) {
          echo '<table>
                  <tr>
                      <th>Account Number</th>
                      <th>Type</th>
                      <th>Actions</th>
                  </tr>';
          while ($row = $chequebookResult->fetch_assoc()) {
              echo '<tr>';
              echo '<td>' . $row['accNum'] . '</td>';
              echo '<td>' . $row['type'] . '</td>';
              echo '<td>';
              echo '<a href="request.php?action=delete&id=' . $row['id'] . '"><button style="background-color: blue; color: white;">Delete</button></a>';
              echo '</td>';
              echo '</tr>';
          }
          echo '</table>';
      } else {
          echo '<p>No chequebook requests found.</p>';
      }

      // Close the Chequebook Request result
      $chequebookResult->close();

      // Close the database connection
      $conn->close();
      ?>

    </table>
  </div>
</body>
</html>
